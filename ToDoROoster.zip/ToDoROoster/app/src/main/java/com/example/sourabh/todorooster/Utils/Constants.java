package com.example.sourabh.todorooster.Utils;

public class Constants {
    public static final String ARG_ID="id";
    public static final String BACK_STACK_SHOW="showModel";

}
